SID = 's1.biband.tk'

SERVERS = {
    "s1.biband.tk": {
        "pass": "bV0WxxiIMdje",
        "priority": 1
    },
    "s2.biband.tk": {
        "pass": "GxEeZp1R9TisTXIOJlJt6WrkS",
        "priority": 2
    }
}

USERNAME = 'namnamir@gmail.com'
PASSWORD = '!@#a4l0i9'

CMD_SSH = '''sshpass -p {0} ssh root@{1} '''
CMD_CPU = '''cat /proc/stat | awk 'NR==1 {usage=($2+$4)*100/($2+$4+$5)} END {print usage}' '''
CMD_MEM = '''free -m | awk 'NR==2 {usage=($3*100)/$2} END {print usage}' '''
CMD_HDD = '''df -h | awk '$NF=="/"{usage=($3*100)/$2} END {print usage}' '''

HARDWARE_FACTOR = {
    "s1.biband.tk": 1.5,
    "s2.biband.tk": 1,
    "s3.biband.tk": 1,
    "s4.biband.tk": 2,
    "s5.biband.tk": 1
}

LIMIT = 75

WAIT = 10
