# biband-coordinator

#Prepration before running the code

- For beign able to run the code, once, you need to login to the server through SSH and accept the key exchange unless the part of the code returns nothing; the ones related to sshpass.
