import os
import socket
import time
import requests
import json


limit = 75
overall_load = 100
server = ['s1.biband.tk', 's2.biband.tk', 's3.biband.tk', 's4.biband.tk', 's5.biband.tk']
password = ['bV0WxxiIMdje','bV0WxxiIMdje','bV0WxxiIMdje','bV0WxxiIMdje','bV0WxxiIMdje']
server_status=[[0,0,0,0,0], [0,0,0,0,0], [0,0,0,0,0], [0,0,0,0,0], [0,0,0,0,0]]
working_servers = {'0':'s1', '1':'s1', '2':'s1', '3':'s1', '4':'s1', '5':'s1', '6':'s1', '7':'s1', '8':'s1', '9':'s1'}


s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)


# Remotely connect to a server and check the resource usage every 10 minutes
a = False
while a:
	for c in range(0, len(server)):
		try:
			s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			s.connect((server[c], 22))
			server_status[c][0] = 1

			print ("================\n", os.popen(''' sshpass -p '%s' ssh root@%s cat /proc/stat | awk 'NR==1 {usage=($2+$4)*100/($2+$4+$5)} END {print usage}' ''' %(password[c], server[c])).readline(),"\n==============")
			# Gets the CPU, HDD and Memory usage of the server by running command lines and parsing them
			CPU = round(float(os.popen(''' sshpass -p '%s' ssh root@%s cat /proc/stat | awk 'NR==1 {usage=($2+$4)*100/($2+$4+$5)} END {print usage}' ''' %(password[c], server[c])).readline()), 2)
			# Calculate the average of CPU
			print ("CPU: ", CPU)
			if  server_status[c][1] != 0:
				server_status[c][1] += CPU
				server_status[c][1] =  server_status[c][1]/2
			else:
				server_status[c][1] =  CPU

			Memory = round(float(os.popen(''' sshpass -p '%s' ssh root@%s free -m | awk 'NR==2 {usage=($3*100)/$2} END {print usage}' ''' %(password[c], server[c])).readline()), 2)
			# Calculate the average of Memory
			print ("Mem: ", Memory)
			if  server_status[c][2] != 0:
				server_status[c][2] += Memory
				server_status[c][2] =  server_status[c][2]/2
			else:
				server_status[c][2] =  Memory

			HDD = round(float(os.popen(''' sshpass -p '%s' ssh root@%s df -h | awk '$NF=="/"{usage=($3*100)/$2} END {print usage}' ''' %(password[c], server[c])).readline()), 2)
			# Calculate the average of HDD
			print ("HDD: ", HDD)
			if  server_status[c][3] != 0:
				server_status[c][3] += HDD
				server_status[c][3] =  server_status[c][3]/2
			else:
				server_status[c][3] =  HDD

		# If there is any error changes the status of the server to offline (0)
		except socket.error as e:
			server_status[c][0] = 0
			print ("Error on server ", c, ": ", e)

		s.close()


	print (server_status)
	# Waits for 10 mins
	time.sleep(600)
	



# Gets token from the server
r     = requests.post('https://s1.biband.tk/api/v1.0/auth', 
					  json = {'username':'namnamir@gmail.com', 'password':'!@#a4l0i9'}
					 )
token = r.json()['access_token']
print (token)


online_servers = []
for i in range(0, 4):
	if server_status[i][0] == 1:
		online_servers.append(i)
print ("servers: ",online_servers)
online_servers = [2,3,1]


# Counts the number of active servers from the config file. The list is something like [1,0,1,1,0,0]
no_servers = len(online_servers)
print ("No. of servers: ",no_servers)


if no_servers == 2:
	for i in range (0,10):
		if i % 2 == 0:
			working_servers[str(i)] = 's'+str(online_servers[0]+1)
		else:
			working_servers[str(i)] = 's'+str(online_servers[1]+1)

elif no_servers == 3:
	for i in range (0,10):
		if 0 <= i <= 3:
			working_servers[str(i)] = 's'+str(online_servers[0]+1)
		elif 4 <= i <= 6:
			working_servers[str(i)] = 's'+str(online_servers[1]+1)
		else:
			working_servers[str(i)] = 's'+str(online_servers[2]+1)

elif no_servers == 4:
	for i in range (0,10):
		if 0 <= i <= 2:
			working_servers[str(i)] = 's'+str(online_servers[0]+1)
		elif 3 <= i <= 5:
			working_servers[str(i)] = 's'+str(online_servers[1]+1)
		elif 6 <= i <= 7:
			working_servers[str(i)] = 's'+str(online_servers[2]+1)
		else:
			working_servers[str(i)] = 's'+str(online_servers[3]+1)

elif no_servers == 5:
	for i in range (0,10):
		if 0 <= i <= 1:
			working_servers[str(i)] = 's'+str(online_servers[0]+1)
		elif 2 <= i <= 3:
			working_servers[str(i)] = 's'+str(online_servers[1]+1)
		elif 4 <= i <= 5:
			working_servers[str(i)] = 's'+str(online_servers[2]+1)
		elif 6 <= i <= 7:
			working_servers[str(i)] = 's'+str(online_servers[3]+1)
		else:
			working_servers[str(i)] = 's'+str(online_servers[4]+1)

print ("list: ", working_servers)


r = requests.post('https://s1.biband.tk/api/v1.0/server', 
				  json = working_servers, 
				  headers={'Authorization': 'JWT ' + token})



# Checks the orverall workload on all servers
for i in range (0, len(server)):
	if server_status[i][0]:
		overall_load += (server_status[i][1] + (2 * server_status[i][2])) / 3

# Removes the idle servers if the overall workload is low
if overall_load <= limit - limit/no_servers:
	print ("remove the server with the least priority")
elif overall_load >= limit:
	print ("add a new server")

	


def bully(n, priority, active, election_id):
    if n != len(priority) and n != len(active):
        return -1;

    max_pid = 0
    print ("Election message is sent to processes")
    for index in range(len(priority)):
        if index + 1 > election_id:
            if priority[index] > max_pid and active[index] == 1:
                max_pid = index + 1;
            print (index + 1)
    return max_pid

'''
if __name__ == "__main__":
    n = 5
    priority = [1,5,3,4,2]
    active = [1,1,0,0,1];
    election_id = 1;
    ret = bully(n, priority, active, election_id);
    print ("co-ordinator = ", str(ret))
 '''
