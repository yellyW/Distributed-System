import os
import socket
import time
import requests
from pprint import pprint
import pickle
import hashlib
from settings import (
    SID,
    SERVERS,
    USERNAME,
    PASSWORD,
    CMD_SSH,
    CMD_CPU,
    CMD_MEM,
    CMD_HDD,
    HARDWARE_FACTOR,
    LIMIT,
    WAIT)


server_status = {}
las_hash = 'begin'
token = {}


def is_active(domain):
    try:
        ssh_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        ssh_socket.connect((domain, 22))
        ssh_socket.close()
        return True
    except:
        return False


def bully():
    """Bully function."""

    cur_priority = SERVERS[SID]['priority']
    cur_coordinator = SID

    for key, value in SERVERS.items():
        if value['priority'] > cur_priority:
            active = is_active(key)
            if active:
                cur_coordinator = key

    print("Current Coordinator: " + cur_coordinator)
    return cur_coordinator == SID


def get_token(domain):
    """Get token from the server."""
    url = 'https://' + domain + '/api/v1.0/auth'
    print(url)
    r = requests.post(
        url,
        json={'username': USERNAME, 'password': PASSWORD})
    if (r.status_code // 100) == 4:
        print("Check Username and Password for ", key)
    r.raise_for_status()
    token = r.json()['access_token']
    # print(token)
    return token


def propogate(finallist):
    """Post server list to servers."""
    for key, value in SERVERS.items():
        try:
            url = 'https://' + key + '/api/v1.0/auth'
            r = requests.post(
                url,
                json=finallist,
                headers={'Authorization': 'JWT ' + token[key]})
            print(r.json)
            if (r.status_code // 100) == 4:
                token[key] = get_token(key)
            r.raise_for_status()
        except Exception as e:
            print("Error on server ", key, ": ", e)
            # Renew the token.


if __name__ == "__main__":

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # Get the tokens for the first time.
    for key, value in SERVERS.items():
        try:
            token[key] = get_token(key)
        except Exception as e:
            print("Error on getting the token from ", key, ": ", e)

    # Connect to a server and check the resource usage periodically
    while True:
        print('== loop ==')
        if not bully():
            time.sleep(WAIT)
            continue
        online_servers = []
        for key, value in SERVERS.items():
            try:
                server_status[key] = {}
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.connect((key, 22))
                server_status[key]['status'] = 1

                print("================\n")
                # Gets the CPU, HDD and Memory usage of the server
                ssh = CMD_SSH.format(value['pass'], key)

                CPU = round(
                    float(os.popen(ssh + CMD_CPU).readline()),
                    2)

                # Calculate the average of CPU
                print("CPU: ", CPU)
                if ('cpu' in server_status[key] and
                        server_status[key]['cpu'] != 0):
                    server_status[key]['cpu'] += CPU
                    server_status[key]['cpu'] = server_status[key]['cpu'] / 2
                else:
                    server_status[key]['cpu'] = CPU

                MEM = round(
                    float(os.popen(ssh + CMD_MEM).readline()),
                    2)

                # Calculate the average of Memory
                print("Mem: ", MEM)
                if ('mem' in server_status[key] and
                        server_status[key]['mem'] != 0):
                    server_status[key]['mem'] += MEM
                    server_status[key]['mem'] = server_status[key]['mem'] / 2
                else:
                    server_status[key]['mem'] = MEM

                HDD = round(
                    float(os.popen(ssh + CMD_HDD).readline()),
                    2)

                # Calculate the average of HDD
                print("HDD: ", HDD)
                if ('hdd' in server_status[key] and
                        server_status[key]['hdd'] != 0):
                    server_status[key]['hdd'] += HDD
                    server_status[key]['hdd'] = server_status[key]['hdd'] / 2
                else:
                    server_status[key]['hdd'] = HDD

                load = ((
                    server_status[key]['cpu'] +
                    (2 * server_status[key]['mem'])) /
                    (3 * HARDWARE_FACTOR[key]))

                # Removes the idle servers if the overall workload is low
                if load <= LIMIT:
                    online_servers.append(key)
                    online_servers.append(key)
                elif load >= LIMIT:
                    online_servers.append(key)

            # If there is any error changes the status to offline (0)
            except socket.error as e:
                server_status[key]['status'] = 0
                print(server_status[key]['status'])
                print("Socket Error on server ", key, ": ", e)

            except Exception as e:
                print("Error on server ", key, ": ", e)
                raise e

            s.close()

        # ====== For Test ======
        # pprint(server_status)
        # pprint(online_servers)
        # online_servers = [
        #     "s1.biband.tk",
        #     "s2.biband.tk",
        #     "s1.biband.tk"]
        # ======================

        # Counts the number of active servers from the config file.
        no_servers = len(online_servers)
        print("No. of servers: ", no_servers)
        pprint(online_servers)

        finallist = {}
        j = 0
        for i in range(0, 10):
            finallist[str(i)] = online_servers[j]
            if j >= len(online_servers) - 1:
                j = 0
            else:
                j = j + 1

        new_hash = hashlib.md5(pickle.dumps(finallist)).hexdigest()
        if new_hash == las_hash:
            print('The server list is same as before.')
            pprint(finallist)
        else:
            print('The server list has been changed.')
            pprint(finallist)
            las_hash = new_hash
            propogate(finallist)

        # Waits for next round
        time.sleep(WAIT)
