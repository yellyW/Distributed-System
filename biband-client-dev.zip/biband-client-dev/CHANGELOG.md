# Change Log
All notable changes to this project will be documented in this file.

## [Next Steps]
### Added
- Getting the Latest Config file automatically.

### Changed
- Sophisticated logging option

### Fixed
- More accurate geolocation API.

## [1.0.8] - 2017-04-03
### Added
- CHANGELOG.
- Logging Module.

### Fixed
- Checking if the HTML title has string content to prevent NoneType error.
- The empty domain field in case of DNS error solved.

### Change
- Send 600 (instead of 100) status code in case of HTML module exception.

## [1.0.7] - 2017-03-03
### Fixed
- Checking if the HTML title exists to prevent NoneType error.

## [1.0.6] - 2017-24-02
### Fixed
- Replace netloc with hostname.

## [1.0.5] - 2017-05-02
### Added
- While loop to retry test after delay.
- Retry if VPN is ON.

## [1.0.5] - 2017-03-02
### Added
- Geolocation Module and VPN Alert.

## [1.0.4] - 2017-28-01
### Fixed
- Limiting the HTML timeout.

## [1.0.3] - 2017-28-01
### Added
- External IP Module. 

## [1.0.0] - 2017-15-01
### Added
- First version including the main loop and modules.
- HTML Module.
- DNS Module.
- TCP Module.
