import requests
from bs4 import BeautifulSoup
import re
from pprint import pprint
import json
from modules.log import log


class HTML(object):
    """docstring for ClassName"""
    def __init__(self, domain):
        self.domain = domain

    def getsource(self):
        try:
            with open('conf.json') as data_file:
                data = json.load(data_file)
        except:
            log('WARN', 'Missing config file in HTML Class.')
            raise

        result = {}

        try:
            headers = {'User-Agent': data['user-agent']}
            r = requests.get(self.domain, headers=headers, timeout=data['timeout'])
            soup = BeautifulSoup(r.content, 'html.parser')

            result["html_status"] = "succeed"
            result["html_status_code"] = r.status_code
            result["html_headers"] = json.dumps(dict(r.headers))
            if soup.title and soup.title.string:
                result["html_title"] = soup.title.string.rstrip()
            else:
                result["html_title"] = ''

            iframes = soup.findAll('iframe',{"src":True}) #soup.findAll('iframe') sources=
            if iframes:
                for iframe in iframes:
                    regex = r"(.*http://10.10..*)"
                    match = re.search(regex, iframe['src'])
                    if match:
                        result["html_iframe"] = match.group(0)
                        return result
                result["html_iframe"] = "None"
            else:
                result["html_iframe"] = "None"

            return result

        except requests.exceptions.Timeout:
            result["html_status"] = "Timeout"
        except requests.exceptions.TooManyRedirects:
            result["html_status"] = "TooManyRedirects"
        except requests.exceptions.SSLError:
            result["html_status"] = "SSLError"
        except requests.exceptions.ConnectionError:
            result["html_status"] = "ConnectionError"
        result["html_iframe"] = "None"
        result["html_status_code"] = 600
        result["html_headers"] = "None"
        result["html_title"] = "None"
        return result
