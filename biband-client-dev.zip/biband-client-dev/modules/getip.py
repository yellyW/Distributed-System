import requests
import json
# from pprint import pprint
from modules.log import log


class GetIP(object):
    def get(self):
        try:
            with open('conf.json') as data_file:
                conf = json.load(data_file)
        except:
            log('WARN', 'Missing config file in GetIP Class.')
            raise

        result = {}

        try:
            r = requests.get(conf['getip'])
            result = r.json()
            log('INFO', 'External IP is: ' + result)
            if "ip" in result:
                return result["ip"]

            return '127.0.0.1'

        except:
            return '127.0.0.1'
