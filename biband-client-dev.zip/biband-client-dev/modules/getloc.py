import requests
import json
from pprint import pprint
from modules.log import log


class GetLoc(object):
    def get(self):
        try:
            with open('conf.json') as data_file:
                conf = json.load(data_file)
        except:
            log('WARN', 'Missing config file in GetLoc Class.')
            raise

        result = {}

        try:
            url = conf['getloc']
            r = requests.get(url)

            result = r.json()
            if "country_code" in result:
                return result["country_code"]

            return 'NA'

        except:
            return 'NA'
