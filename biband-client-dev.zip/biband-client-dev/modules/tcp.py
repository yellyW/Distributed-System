import socket

class TCP(object):
    """docstring for TCP"""
    def __init__(self, ip):
        # super(TCP, self).__init__()
        self.ip = ip

    def checktcp(self, port = 80):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        result = {}

        try:
            s.connect((self.ip, port))
            result['tcp_status'] = False
            s.close()
            return result

        except:
            result['tcp_status'] = True
            return result


