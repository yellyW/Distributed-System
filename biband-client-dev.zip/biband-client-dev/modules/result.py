import requests
import json
from pprint import pprint
from modules.log import log


class Result(object):
    """docstring for Domain."""

    def __init__(self, data):
        self.data = data

    def send(self, server):
        try:
            with open('conf.json') as data_file:
                conf = json.load(data_file)
        except:
            log('WARN', 'Missing config file in Result Class.')
            raise

        try:
            url = "https://" + server + conf['result']
            headers = {
                'User-Agent': conf['user-agent'],
                "content-type": "application/json"}
            r = requests.post(url, json=self.data, headers=headers)

            result = r.json()

            return result

        except Exception as e:
            pprint(e)
            result = "failed"
            return result
