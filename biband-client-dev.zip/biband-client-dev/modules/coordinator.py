import ipaddress
import requests
import json
from modules.getip import GetIP


class Coordinator():
    """docstring for Coordinator"""
    def get(self):
        try:
            with open('conf.json') as data_file:
                conf = json.load(data_file)
        except:
            print("Missing config file in Domain Class")
            raise

        try:
            url = "https://" + conf['hos'] + conf['server']
            headers = {
                'User-Agent': conf['user-agent'],
                "content-type": "application/json"}
            r = requests.get(url, headers=headers)
            server_list = r.json()

            ip = int(ipaddress.ip_address(GetIP().get()))
            last_digit = ip % 10

            return server_list[str(last_digit)]

        except:
            print('Error in getting server list. use default one.')
            return conf['hos']
