import requests
import json
# from pprint import pprint
from modules.log import log


class Domain(object):

    def getlist(self, server):
        try:
            with open('conf.json') as data_file:
                conf = json.load(data_file)
        except:
            print("Missing config file in Domain Class")
            raise

        result = {}

        try:
            url = "https://" + server + conf['domain']
            headers = {
                'User-Agent': conf['user-agent'],
                "content-type": "application/json"}
            r = requests.get(url, headers=headers)

            result["domains"] = r.json()
            if "message" in result["domains"]:
                log('WARN', result["domains"]["message"])
                result["status"] = "failed"
                return result
            result["status"] = "succeed"
            return result

        except:
            result["status"] = "failed"
            return result
