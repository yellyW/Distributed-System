import dns.resolver
from urllib.parse import urlparse
import random
from pprint import pprint


class DNS(object):
    def __init__(self, domain):
        self.domain = urlparse(domain).hostname
        self.alterdomain = DNS.alternate(urlparse(domain).hostname)

    def checkdns(self):
        r1 = dns.resolver.Resolver()
        # myResolver.nameservers = ['8.8.8.8', '8.8.4.4']
        result = {}

        try:
            myAnswers = r1.query(self.domain, "A")
            for rdata in myAnswers:
                result["dns_status"] = "succeed"
                result["dns_domain"] = self.domain
                result["dns_ip"] = str(rdata)

        except:
            result["dns_status"] = "failed"
            result["dns_domain"] = self.domain
            result["dns_ip"] = ""

        r2 = dns.resolver.Resolver()
        try:
            myAnswers = r2.query(self.alterdomain, "A")
            for rdata in myAnswers:
                result["dns_alter_status"] = "succeed"
                result["dns_alter_domain"] = self.alterdomain
                result["dns_alter_ip"] = str(rdata)

        except:
            result["dns_alter_status"] = "failed"
            result["dns_alter_domain"] = self.alterdomain
            result["dns_alter_ip"] = ""

        return result

    @classmethod
    def alternate(cls, domain):
        d = ''
        for c in domain:
            if c is not '.' and bool(random.getrandbits(1)):
                d += c.upper()
            else:
                d += c
        return d
