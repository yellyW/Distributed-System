import datetime
import time


def log(outa, outb):
    st = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
    print("{0} - {1} - {2}".format(st, outa, outb) )
