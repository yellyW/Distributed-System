import sys
import time
from modules.dns import DNS
from modules.html import HTML
from modules.tcp import TCP
from modules.domains import Domain
from modules.result import Result
from modules.getloc import GetLoc
from modules.log import log
from modules.coordinator import Coordinator
from pprint import pprint
import json


def check(version):
    server = Coordinator().get()
    domains = Domain(server).getlist()
    result = {}
    # pprint(domains['domains']['domains'])

    if domains['status'] == 'succeed':
        log('INFO', 'The New Domain Lists:')
        pprint(domains)
        # ip = GetIP().get()
        for domain in domains['domains']['domains']:
            log('INFO', 'checking the url ' + domain['url'])
            result[domain['id']] = {}

            # result[domain['id']]['client_ip'] = ip

            result[domain['id']]['domain_id'] = domain['id']

            result[domain['id']]['client_version'] = version

            dns = DNS(domain=domain['url'])
            resd = dns.checkdns()
            result[domain['id']]['dns_status'] = resd['dns_status']
            result[domain['id']]['dns_domain'] = resd['dns_domain']
            result[domain['id']]['dns_ip'] = resd['dns_ip']
            result[domain['id']]['dns_alter_status'] = resd['dns_alter_status']
            result[domain['id']]['dns_alter_domain'] = resd['dns_alter_domain']
            result[domain['id']]['dns_alter_ip'] = resd['dns_alter_ip']

            html = HTML(domain=domain['url'])
            resh = html.getsource()
            result[domain['id']]['html_status'] = resh['html_status']
            result[domain['id']]['html_status_code'] = resh['html_status_code']
            result[domain['id']]['html_headers'] = resh['html_headers']
            result[domain['id']]['html_title'] = resh['html_title']
            result[domain['id']]['html_iframe'] = resh['html_iframe']

            result[domain['id']]['tcp'] = {}
            tcp = TCP(domain['ip'])
            rest8 = tcp.checktcp(80)
            result[domain['id']]['tcp_80_isblocked'] = rest8['tcp_status']
            rest4 = tcp.checktcp(443)
            result[domain['id']]['tcp_443_isblocked'] = rest4['tcp_status']

            r = Result(result[domain['id']])
            send_response = r.send(server)
            if send_response == "failed":
                time.sleep(90)
    else:
        log('WARN', 'An error occurred in the API Server.')
        time.sleep(90)

while True:
    try:
        with open('conf.json') as data_file:
            conf = json.load(data_file)
        while True:
            country = GetLoc()
            if conf['vpnalert'].lower() == 'true' and country.get() != 'IR':
                log('WARN', 'Please turn off the VPN and run the script again.')
                time.sleep(conf['delay'])
                continue

            check(conf['v'])
            log('INFO', 'Waiting for next round.')
            time.sleep(conf['delay'])
    except Exception as e:
        log('WARN', e)
        time.sleep(90)
    except KeyboardInterrupt:
        log('INFO', 'Closing the app.')
        sys.exit(1)
