# biband-client

# Install
apt install python3 git python3-dev python-pip

pip3 install virtualenv

git clone -b dev --single-branch https://github.com/baaroo/biband-client.git

cd biband-client

virtualenv -p python3 venv

. venv/bin/activate

pip install -r requirements.txt


python app.py
