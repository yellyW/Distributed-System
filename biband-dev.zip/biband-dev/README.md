# biband


# Install

```
apt install git python3 python3-pip python3-dev postgresql-server-dev-X.Y 

cd /home/biband/public_html
git clone -b dev --single-branch https://github.com/baaroo/biband.git


cd biband

pip3 install virtualenv

virtualenv -p python3 venv

. venv/bin/activate

pip install -r requirements.txt

pip install --editable .

deactivate
```


# redis
apt install redis-server

```
nano /etc/redis/redis.conf
```
and set password
```
service redis restart
```


# Postgresql

set password for first time:
```
sudo -u postgres psql postgres
\password postgres
\q
```


set md5 for authentication in:
/etc/postgresql/*.*/main/pg_hba.conf

```
local   all             all                                     md5
host    all             all             ::1/128                 md5
```

and restart the Postgres:
```
service postgresql restart
```

# Apach2
activate this modules:
```
proxy proxy_ajp proxy_http rewrite deflate headers proxy_balancer proxy_connect proxy_html
```


# Initial the Database

```
biband db init
biband db seed
biband option
```

# gunicorn

```
gunicorn -b 0.0.0.0:8000 --access-logfile - "wsgi:app"
```

# Service
create service files in:
/etc/systemd/system/

reload the system control and start the service:
```
systemctl daemon-reload

systemctl enable biband
service biband start

systemctl enable bibandcelery
service bibandcelery start
```
