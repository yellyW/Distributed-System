from flask import (
    Blueprint,
    # flash,
    # redirect,
    request,
    render_template)
from sqlalchemy import text
from biband.blueprints.api.models.domains import DomainModel
from biband.blueprints.measurement.models import DomainInsight, ResultInsight
# from biband.blueprints.measurement.models import SearchURL, CatInsight
from biband.blueprints.measurement.forms import SearchForm
from biband.blueprints.api.models.categories import CatModel
from biband.blueprints.admin.optionmodels import Options


measurement = Blueprint('measurement', __name__, template_folder='templates')


@measurement.route('/measurement/id/<int:id>')
def domains(id):
    group_result_status = DomainInsight.group_result_status(id)
    # group_domains_dns = DomainInsight.group_domains_dns(id)
    # group_domains_html = DomainInsight.group_domains_html(id)
    # group_domains_tcp_80 = DomainInsight.group_domains_tcp_80(id)
    # group_domain_city = DomainInsight.group_domain_city(id)
    domain = DomainModel.find_by_id(id)

    categories = CatModel.getlist()

    return render_template(
        'measurement/show.html',
        group_domain_status=group_result_status,
        # group_domains_dns=group_domains_dns,
        # group_domains_html=group_domains_html,
        # group_domains_tcp_80=group_domains_tcp_80,
        # group_domain_city=group_domain_city,
        categories=categories,
        domain=domain)


@measurement.route(
    '/measurement',
    defaults={'page': 1},
    methods=['GET'])
@measurement.route('/measurement/page/<int:page>', methods=['GET'])
# @search.route('/measurement', methods=['GET', 'POST'])
def index(page):
    group_result_status = []
    group_domains_dns = []
    group_domains_html = []
    group_domains_tcp_80 = []
    group_domain_city = []
    domain = []
    search_form = SearchForm()
    sort_by = DomainModel.sort_by(
        request.args.get('sort', 'created_on'),
        request.args.get('direction', 'desc'))
    order_values = '{0} {1}'.format(sort_by[0], sort_by[1])

    rows_query = Options.get('rows_qty')
    if hasattr(rows_query, 'value'):
        rows_qty = int(rows_query.value)
    else:
        rows_qty = 10

    if request.args.get('q', '', type=str):
        paginated_domains = DomainModel.query \
            .filter(DomainModel.search(request.args.get('q', ''))) \
            .order_by(text(order_values)) \
            .paginate(page, rows_qty, True)

    else:
        paginated_domains = []
        # group_domain_status = DomainInsight.group_domain_status(0)
        # group_domains_dns = DomainInsight.group_domains_dns(0)
        # group_domains_html = DomainInsight.group_domains_html(0)
        # group_domains_tcp_80 = DomainInsight.group_domains_tcp_80(0)
        # group_domain_city = DomainInsight.group_domain_city(0)

        group_result_status = ResultInsight.group_result_status()
        group_domains_dns = ResultInsight.group_domains_dns()
        group_domains_html = ResultInsight.group_domains_html()
        group_domains_tcp_80 = ResultInsight.group_domains_tcp_80()
        group_domain_city = ResultInsight.group_domain_city()
        domain = []
        # DomainModel.find_by_id(0)

    return render_template(
        'measurement/index.html',
        form=search_form,
        domains=paginated_domains,
        group_domain_status=group_result_status,
        group_domains_dns=group_domains_dns,
        group_domains_html=group_domains_html,
        group_domains_tcp_80=group_domains_tcp_80,
        group_domain_city=group_domain_city,
        domain=domain)


# @measurement.route('/measurement/cat/<string:name>')
# def categories(name):
#     group_domain_status = CatInsight.group_cat_status(name)
#     # domain = DomainModel.find_by_id(id)

#     return render_template('measurement/show.html',
#                            group_domain_status=group_domain_status,
#                            group_domains_dns=group_domains_dns,
#                            group_domains_html=group_domains_html,
#                            group_domains_tcp_80=group_domains_tcp_80,
#                            group_domain_city=group_domain_city,
#                            domain=domain
#                            )
