from flask_wtf import FlaskForm
# from flaskform import Form, RecaptchaField
from wtforms import TextField, StringField
from wtforms.validators import DataRequired, Length, URL, Optional


class DomainSearch(FlaskForm):
    """docstring for DomainSearch"""
    domain = TextField(
        'Check the Domain: http://example.com',
        [
            DataRequired(), Length(1, 255),
            URL('Please check the URL format.')
        ])
    # recaptcha = RecaptchaField()


class SearchForm(FlaskForm):
    q = StringField('Search terms', [Optional(), Length(1, 256)])
