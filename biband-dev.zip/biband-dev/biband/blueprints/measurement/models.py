from sqlalchemy import func, desc, asc
from sqlalchemy import or_, text
from biband.blueprints.api.models.results import ResultModel
from biband.blueprints.api.models.domains import DomainModel

from lib.util_sqlalchemy import ResourceMixin, AwareDateTime
from biband.extensions import db
from datetime import datetime, timedelta
from lib.util_datetime import tzware_datetime


class DomainInsight(object):
    @classmethod
    def group_result_status(cls, id):
        return DomainInsight._group_and_count_id(
            ResultModel, id, ResultModel.status)

    @classmethod
    def group_domain_city(cls, id):
        return DomainInsight._city_and_count_id(
            ResultModel, id, ResultModel.status, "blocked",
            ResultModel.client_city)

    @classmethod
    def group_domains_dns(cls, id):
        return DomainInsight._filter_and_count_id(
            ResultModel, id, ResultModel.dns_isblocked, True)

    @classmethod
    def group_domains_dns_b(cls, id):
        return DomainInsight._group_and_count_id(
            ResultModel, id, ResultModel.dns_isblocked)

    @classmethod
    def group_domains_html(cls, id):
        return DomainInsight._filter_and_count_id(
            ResultModel, id, ResultModel.html_isblocked, True)

    @classmethod
    def group_domains_html_b(cls, id):
        return DomainInsight._group_and_count_id(
            ResultModel, id, ResultModel.html_isblocked)

    @classmethod
    def group_domains_tcp_80(cls, id):
        return DomainInsight._filter_and_count_id(
            ResultModel, id, ResultModel.tcp_80_isblocked, True)

    @classmethod
    def group_domains_tcp_80_b(cls, id):
        return DomainInsight._group_and_count_id(
            ResultModel, id, ResultModel.tcp_80_isblocked)

    @classmethod
    def inactive_domains(cls):
        return DomainInsight._filter_and_count(
            DomainModel, DomainModel.active, False)

    @classmethod
    def _group_and_count(cls, model, field):
        """
        Group results for a specific model and field.

        :param model: Name of the model
        :type model: SQLAlchemy model
        :param field: Name of the field to group on
        :type field: SQLAlchemy field
        :return: dict
        """
        count = func.count(field)
        query = db.session.query(count, field).group_by(field).all()

        results = {
            'query': query,
            'total': model.query.count()
        }

        return results

    @classmethod
    def _group_and_count_id(cls, model, id, field):
        if id == 0:
            count = func.count(field)
            query = db.session.query(count, field).group_by(field).all()
            count2 = db.session.query(field).count()

            results = {
                'query': query,
                # 'total': model.query.count()
                'total': count2
            }
        else:
            count = func.count(field)
            query = db.session.query(count, field)\
                .filter_by(domain_id=id).group_by(field).all()
            count2 = db.session.query(field)\
                .filter_by(domain_id=id).count()

            results = {
                'query': query,
                # 'total': model.query.count()
                'total': count2
            }

        return results

    @classmethod
    def _filter_and_count(cls, model, field, filter):
        count = func.count(field)
        query = db.session.query(count, field)\
            .filter(field.is_(filter)).group_by(field).all()

        results = {
            'query': query,
            'total': model.query.count()
        }

        return results

    @classmethod
    def _filter_and_count_id(cls, model, id, field, filter):
        if id == 0:
            count = func.count(field)
            query = db.session.query(count, field)\
                .filter(field.is_(filter)).group_by(field).all()

            results = {
                'query': query,
                'total': model.query.count()
            }
        else:
            count = func.count(field)
            query = db.session.query(count, field).filter_by(domain_id=id)\
                .filter(field.is_(filter)).group_by(field)

            results = {
                'query': query,
                'total': model.query.count()
            }

        return results

    @classmethod
    def _city_and_count_id(cls, model, id, field, filter, gfield):
        if id == 0:
            count = func.count(field)
            query = db.session.query(count, gfield).group_by(gfield).all()
            count2 = db.session.query(gfield).count()

            results = {
                'query': query,
                # 'total': model.query.count()
                'total': count2
            }
        else:
            count = func.count(field)
            query = db.session.query(count, gfield)\
                .filter_by(domain_id=id).group_by(gfield)
            count2 = db.session.query(gfield).filter_by(domain_id=id).count()

            results = {
                'query': query,
                # 'total': model.query.count()
                'total': count2
            }

        return results

    @classmethod
    def find_latest(cls, n):
        """
        Latest n results

        :param model: Name of the model
        :type model: SQLAlchemy model
        :param n: quantity of requested results
        :type n: integer
        :return: dict
        """

        return ResultModel.query.order_by(ResultModel.id.desc()).limit(n)

    @classmethod
    def find_last(cls):
        """
        Latest n results

        :param model: Name of the model
        :type model: SQLAlchemy model
        :param n: quantity of requested results
        :type n: integer
        :return: dict
        """

        return ResultModel.query.order_by(ResultModel.id.desc()).first()

    @classmethod
    def find_latest_by_cat(cls, n, cat):
        subquery = db.session.query(
            DomainModel.id, DomainModel.cat_id)\
            .subquery()
        query = db.session.query(
            ResultModel.id,
            subquery.c.cat_id)\
            .outerjoin(subquery)\
            .filter_by(cat_id=cat)\
            .order_by(ResultModel.id.desc())\
            .limit(n)
        # print(query)
        return query

    @classmethod
    def find_all_by_id(cls, id, d):
        since = tzware_datetime() - timedelta(days=d)
        query = db.session.query(
            ResultModel.id,
            ResultModel.dns_ip,
            ResultModel.created_on,
            ResultModel.domain_id)\
            .filter(ResultModel.created_on > since)\
            .filter_by(domain_id=id)\
            .order_by(ResultModel.id.desc()).all()
        # print(query)
        return query


class SearchURL(object):
    @classmethod
    def search(cls, url):
        """
        Perform a group by/count on all users.

        :return: dict
        """
        return SearchURL._search(DomainModel, url)

    @classmethod
    def _search(cls, model, url):
        """
        Group results for a specific model and field.

        :param model: Name of the model
        :type model: SQLAlchemy model
        :param field: Name of the field to group on
        :type field: SQLAlchemy field
        :return: dict
        """
        print(url)
        results = model.query.filter_by(url=url)\
            .order_by(model.created_on.desc()).first()

        return results


class CatInsight(object):
    @classmethod
    def group_cat_status(cls, category):
        if category == 'dns':
            return CatInsight._group_and_count_id(
                ResultModel, ResultModel.dns_isblocked,
                ResultModel.domain_id)
        elif category == 'html':
            return CatInsight._group_and_count_id(
                ResultModel, ResultModel.html_isblocked,
                ResultModel.domain_id)
        elif category == 'tcp':
            return CatInsight._group_and_count_id(
                ResultModel, ResultModel.tcp_80_isblocked,
                ResultModel.domain_id)
        return None

    @classmethod
    def _group_and_count(cls, model, filter, field):

        count = func.count(field)
        query = db.session.query(count, field)\
            .filter(field.is_(True)).group_by(field).all()

        results = {
            'query': query,
            'total': model.query.count()
        }

        return results


class ResultInsight(ResourceMixin, db.Model):

    __tablename__ = 'resultinsights'

    id = db.Column(db.Integer, primary_key=True)
    insighttype = db.Column(db.String(255), nullable=False, index=True)
    insightname = db.Column(db.String(255), nullable=False, index=True)
    insightquantity = db.Column(db.Integer, nullable=False, default=0)

    def __init__(self, **kwargs):
        # Call Flask-SQLAlchemy's constructor.
        super(ResultInsight, self).__init__(**kwargs)

    @classmethod
    def find_by_name(cls, ftype, name):
        result = ResultInsight.query.filter_by(
            insighttype=ftype,
            insightname=name)\
            .first()
        return result

    @classmethod
    def find_all_cities(cls):
        result = ResultInsight.query.filter_by(insighttype='city').all()
        ids = [row.id for row in result]
        return ids

    @classmethod
    def group_result_status(cls):
        total = ResultInsight.find_by_name('total', 'totalresult')
        query = db.session.query(
            ResultInsight.insightquantity,
            ResultInsight.insightname)\
            .filter_by(insighttype='status').all()
        result = {
            'query': query,
            'total': total.insightquantity}
        return result

    @classmethod
    def group_domains_dns(cls):
        return ResultInsight._filter_and_count('dns')

    @classmethod
    def group_domains_html(cls):
        return ResultInsight._filter_and_count('html')

    @classmethod
    def group_domains_tcp_80(cls):
        return ResultInsight._filter_and_count('tcp80')

    @classmethod
    def _filter_and_count(cls, filter):
        query = db.session.query(ResultInsight.insightquantity)\
            .filter_by(insighttype=filter).all()

        results = {
            'query': query
        }

        return results

    @classmethod
    def group_domain_city(cls):
        query = db.session.query(
            ResultInsight.insightquantity,
            ResultInsight.insightname)\
            .filter_by(insighttype='city').all()

        results = {
            'query': query
        }

        return results
