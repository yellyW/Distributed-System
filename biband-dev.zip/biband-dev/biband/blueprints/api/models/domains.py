# import requests
import socket
from collections import OrderedDict
from urllib.parse import urlparse
from sqlalchemy import or_, text, and_
from sqlalchemy import func, desc, asc
from biband.extensions import db
from lib.util_sqlalchemy import ResourceMixin
# from lib.util_enum import util_enum
from sqlalchemy_utils import URLType
# from pprint import pprint
from biband.blueprints.api.models.results import ResultModel
from sqlalchemy.sql.expression import label
from sqlalchemy.sql.functions import coalesce


class DomainModel(ResourceMixin, db.Model):
    PRIORITY = OrderedDict([
        ('1', 'Emergency'),
        ('2', 'High'),
        ('3', 'Moderate'),
        ('4', 'Low')
    ])

    CAT = OrderedDict([
        ('art', 'Art'),
        ('education', 'Education'),
        ('business', 'Business'),
        ('game', 'Game'),
        ('tech', 'Tech'),
        ('health', 'Health'),
        ('news', 'News'),
        ('fashion', 'Fashion'),
        ('recreation', 'Recreation'),
        ('reference', 'Reference'),
        ('science', 'Science'),
        ('society', 'Society'),
        ('sport', 'Sport'),
        ('porn', 'Porn'),
        ('politics', 'Politics'),
        ('na', 'N/A')
    ])

    __tablename__ = 'domains'

    id = db.Column(db.Integer, primary_key=True)
    url = db.Column(URLType(), nullable=False, index=True)
    ip = db.Column(
        db.String(16), nullable=False, index=True,
        server_default='1.1.1.1')
    priority = db.Column(
        db.Enum(*PRIORITY, name='priority_types', native_enum=False),
        nullable=False,
        index=True)
    cat1 = db.Column(
        db.Enum(*CAT, name='cat1_types', native_enum=False),
        index=True, server_default='na')
    cat2 = db.Column(
        db.Enum(*CAT, name='cat2_types', native_enum=False),
        index=True, server_default='na')
    cat3 = db.Column(
        db.Enum(*CAT, name='cat3_types', native_enum=False),
        index=True, server_default='na')
    cat_id = db.Column(db.Integer, db.ForeignKey('categories.id'), default=1)
    cat_id2 = db.Column(db.Integer, db.ForeignKey('categories.id'), default=1)
    cat_id3 = db.Column(db.Integer, db.ForeignKey('categories.id'), default=1)
    active = db.Column(db.Boolean(), nullable=False, server_default='1')

    results = db.relationship(
        'ResultModel', backref='domain',
        cascade="all, delete-orphan",
        lazy='dynamic')

    cat_rel = db.relationship("CatModel", foreign_keys=[cat_id])
    cat2_rel = db.relationship("CatModel", foreign_keys=[cat_id2])
    cat3_rel = db.relationship("CatModel", foreign_keys=[cat_id3])

    def __init__(self, **kwargs):
        super(DomainModel, self).__init__(**kwargs)

    def json(self):
        return {
            'id': self.id,
            'url': self.url,
            'ip': self.ip,
            'cat_id': self.cat_id,
            'priority': self.priority}

    @classmethod
    def find_by_url(cls, url):
        return DomainModel.query.filter_by(url=url).first()

    @classmethod
    def find_by_id(cls, id):
        return DomainModel.query.filter_by(id=id).first()

    @classmethod
    def find_by_catprt(cls, cat, priority):
        return DomainModel.query.filter(DomainModel.active.is_(True))\
            .filter_by(cat1=cat).filter_by(priority=priority).all()

    @classmethod
    def find_by_ip(cls, ip):
        return DomainModel.query.filter_by(ip=ip).all()

    @classmethod
    def find_by_ip_qty(cls, ip):
        return DomainModel.query.filter_by(ip=ip).count()

    @classmethod
    def find_by_cat(cls, cid):
        return DomainModel.query.filter_by(cat_id=cid).all()

    @classmethod
    def find_by_cat_qty(cls, cid):
        return DomainModel.query.filter_by(cat_id=cid).count()

    @classmethod
    def find_by_cat2(cls):
        return DomainModel.query.filter_by(cat_id2=None).all()

    @classmethod
    def find_by_cat3(cls):
        return DomainModel.query.filter_by(cat_id3=None).all()

    @classmethod
    def random(cls, cat, priority):
        domain = DomainModel.query.order_by(func.random().desc())\
                            .filter(DomainModel.active.is_(True))\
                            .filter_by(cat_id=cat)\
                            .filter_by(priority=priority).first()
        if domain:
            return DomainModel.query.get(domain.id)
        return None

    @classmethod
    def findleast(cls, cat, priority, limit):
        subquery = db.session.query(
            ResultModel.domain_id,
            func.count(ResultModel.id).label('count'))\
            .group_by(ResultModel.domain_id).subquery()

        total_amount = coalesce(subquery.c.count, 0)

        query = db.session.query(
            DomainModel.id, DomainModel.url,
            DomainModel.ip, DomainModel.active,
            DomainModel.cat_id, DomainModel.priority,
            label('count', total_amount))\
            .filter(DomainModel.active.is_(True)).filter_by(cat_id=cat)\
            .filter_by(priority=priority).group_by(DomainModel.id)\
            .outerjoin(subquery)\
            .group_by(None)\
            .order_by(desc('count'))\
            .limit(limit)
        return query

    @classmethod
    def findnone(cls, cat, priority, limit):
        subquery = db.session.query(
            ResultModel.domain_id,
            func.count(ResultModel.id).label('count'))\
            .group_by(ResultModel.domain_id).subquery()
        query = db.session.query(
            DomainModel.id, DomainModel.url,
            DomainModel.ip, DomainModel.active,
            DomainModel.cat_id, DomainModel.priority, subquery.c.count)\
            .filter(DomainModel.active.is_(True)).filter_by(cat_id=cat)\
            .filter_by(priority=priority).group_by(DomainModel.id)\
            .outerjoin(subquery)\
            .group_by(None).filter_by(count=None)\
            .order_by(func.random())\
            .limit(limit)
        return query

    @classmethod
    def findnone_qty(cls):
        subquery = db.session.query(
            ResultModel.domain_id,
            func.count(ResultModel.id).label('count'))\
            .group_by(ResultModel.domain_id).subquery()
        query = db.session.query(
            DomainModel.id, DomainModel.url,
            DomainModel.ip, DomainModel.active,
            DomainModel.cat_id, DomainModel.priority, subquery.c.count)\
            .filter(DomainModel.active.is_(True))\
            .group_by(DomainModel.id)\
            .outerjoin(subquery)\
            .group_by(None).filter_by(count=None).count()
        return query

    @classmethod
    def createsample(cls, cat, priority, limit):
        subquery = db.session.query(
            ResultModel.domain_id,
            func.count(ResultModel.id).label('count'))\
            .group_by(ResultModel.domain_id).subquery()

        total_amount = coalesce(subquery.c.count, 0)

        query = db.session.query(
            DomainModel.id, DomainModel.url,
            DomainModel.ip, DomainModel.active,
            DomainModel.cat_id, DomainModel.priority,
            label('count', total_amount))\
            .filter(DomainModel.active.is_(True)).filter_by(cat_id=cat)\
            .filter_by(priority=priority).group_by(DomainModel.id)\
            .outerjoin(subquery)\
            .group_by(None)\
            .order_by(asc('count'))\
            .limit(limit)

        items = []
        for nonedomain in query:
            item = {
                "id": nonedomain.id,
                "url": nonedomain.url,
                "ip": nonedomain.ip,
                "priority": nonedomain.priority,
                "cat_id": nonedomain.cat_id}
            items.append(item)
            print(
                "id:" + str(nonedomain.id) + ", count:" +
                str(nonedomain.count))

        if len(items) > 0:
            db.engine.execute(DomainSample.__table__.insert(), items)

        return 'done'

    @classmethod
    def search(cls, query):
        """
        Search a resource by IP or URL
        """
        if not query:
            # print('noquery')
            return text('')

        search_query = '%{0}%'.format(query)
        search_chain = (DomainModel.url.ilike(search_query),
                        DomainModel.ip.ilike(search_query))

        return or_(*search_chain)

    @classmethod
    def filter_cat(cls, query):
        """
        Filter a resource by category
        """
        if not (query):
            return text('')

        return (DomainModel.cat_id == query)

    @classmethod
    def filter_priority(cls, query):
        """
        Filter a resource by category
        """
        if not (query):
            return text('')

        filter_pr = '%{0}%'.format(query)

        return DomainModel.priority.ilike(filter_pr)

    def save_ip(self):
        baseurl = urlparse(self.url).hostname
        try:
            self.ip = socket.gethostbyname(baseurl)
        except Exception as e:
            print(e)
            self.ip = '127.0.0.1'
            self.active = False

        db.session.add(self)
        db.session.commit()

    @classmethod
    def all_domains(cls):
        return cls.query.count()


class DomainSample(ResourceMixin, db.Model):
    PRIORITY = DomainModel.PRIORITY

    __tablename__ = 'domainsample'

    id = db.Column(db.Integer, primary_key=True)
    url = db.Column(URLType(), nullable=False, index=True)
    ip = db.Column(
        db.String(16), nullable=False, index=True,
        server_default='1.1.1.1')
    priority = db.Column(
        db.Enum(*PRIORITY, name='priority_types', native_enum=False),
        nullable=False, index=True)
    cat_id = db.Column(db.Integer, default=1, index=True)

    def __init__(self, **kwargs):
        super(DomainSample, self).__init__(**kwargs)

    def json(self):
        return {
            'id': self.id,
            'url': self.url,
            'ip': self.ip,
            'cat_id': self.cat_id,
            'priority': self.priority}

    @classmethod
    def deleteall(cls, cat, priority):
        count = DomainSample.query.filter_by(cat_id=cat)\
            .filter_by(priority=priority).delete()
        db.session.commit()
        return count

    @classmethod
    def getrandom(cls, cat, priority, limit):
        query = DomainSample.query.filter_by(cat_id=cat)\
            .filter_by(priority=priority)\
            .group_by(None)\
            .order_by(func.random())\
            .limit(limit)
        return query
