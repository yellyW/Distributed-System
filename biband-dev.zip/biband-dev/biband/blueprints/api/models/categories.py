from sqlalchemy import or_, text, func
from biband.extensions import db
from lib.util_sqlalchemy import ResourceMixin
from biband.blueprints.api.models.domains import DomainModel


class CatModel(ResourceMixin, db.Model):
    __tablename__ = 'categories'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128), unique=True, index=True)
    domains = db.relationship(
        'DomainModel',
        primaryjoin="or_(CatModel.id==DomainModel.cat_id, CatModel.id==\
        DomainModel.cat_id2, CatModel.id==DomainModel.cat_id3)",
        backref='category', cascade="all, delete-orphan", lazy='dynamic')

    def __init__(self, **kwargs):
        super(CatModel, self).__init__(**kwargs)

    def json(self):
        return {'id': self.id, 'Category': self.name}

    @classmethod
    def getall(cls):
        return CatModel.query.all()

    @classmethod
    def getlist(cls):
        items = CatModel.query.all()
        results = [None] * len(items)
        for item in items:
            results[item.id - 1] = item.name
        return results

    @classmethod
    def find_by_id(cls, id):
        return CatModel.query.filter_by(id=id).first()

    @classmethod
    def search(cls, query):
        """
        Search a resource by IP or URL
        """
        if not query:
            return text('')

        search_query = '%{0}%'.format(query)
        search_chain = (CatModel.name.ilike(search_query))

        return search_chain

    # @classmethod
    # def getdomainscount1(cls, name):
    #     """
    #     Return the list of domains in this category
    #     """
    #     query = CatModel.query.\
    #         join(DomainModel, CatModel.id == DomainModel.cat_id).\
    #         filter(CatModel.name == name).\
    #         count()

    #     return query

    @classmethod
    def getdomainscount(cls):
        """
        Return the list of domains in this category.
        """
        query = db.session.query(
            CatModel.id.label('id'),
            func.count(DomainModel.id).label('count')).\
            outerjoin(DomainModel, CatModel.id == DomainModel.cat_id).\
            group_by(CatModel.id).all()

        items = {}
        for cat in query:
            items[cat.id] = cat.count

        return items

    @classmethod
    def total(cls):
        """
        Total of the Categories
        """

        return CatModel.query.count()
