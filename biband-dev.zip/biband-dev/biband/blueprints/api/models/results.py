from collections import OrderedDict
import requests
import re
from biband.extensions import db
from lib.util_sqlalchemy import ResourceMixin
from sqlalchemy.dialects.postgresql import JSON
from biband.blueprints.api.models.ip2location import Ip4Model, Ip6Model
import ipaddress


class ResultModel(ResourceMixin, db.Model):
    DNS_S = OrderedDict([
        ('succeed', 'Succeed'),
        ('failed', 'Failed')
    ])

    HTML_S = OrderedDict([
        ('succeed', 'Succeed'),
        ('Timeout', 'Timeout'),
        ('TooManyRedirects', 'TooManyRedirects'),
        ('SSLError', 'SSLError'),
        ('ConnectionError', 'ConnectionError')
    ])

    TCP_S = OrderedDict([
        ('blocked', 'Blocked'),
        ('accessible', 'Accessible')
    ])

    STATUS_S = OrderedDict([
        ('blocked', 'Blocked'),
        ('accessible', 'Accessible')
    ])

    __tablename__ = 'results'

    id = db.Column(db.Integer, primary_key=True)
    domain_id = db.Column(db.Integer, db.ForeignKey('domains.id'))

    dns_status = db.Column(
        db.Enum(*DNS_S, name='dns_statuses', native_enum=False),
        nullable=False, index=True)
    dns_isblocked = db.Column(db.Boolean, nullable=False, index=True)
    dns_domain = db.Column(db.String(255), nullable=False, index=True)
    dns_ip = db.Column(
        db.String(16), nullable=False, index=True,
        server_default='0.0.0.0')
    dns_alter_status = db.Column(
        db.Enum(*DNS_S, name='dns_alter_statuses', native_enum=False),
        nullable=False, index=True)
    dns_alter_domain = db.Column(db.String(255), nullable=False, index=True)
    dns_alter_ip = db.Column(
        db.String(16), nullable=False, index=True,
        server_default='0.0.0.0')

    html_status = db.Column(
        db.Enum(*HTML_S, name='html_statuses', native_enum=False),
        nullable=False, index=True)
    html_isblocked = db.Column(db.Boolean, nullable=False, index=True)
    html_status_code = db.Column(
        db.Integer, nullable=False, index=True,
        default=100)
    html_headers = db.Column(JSON)
    html_title = db.Column(db.String(255), nullable=False, index=True)
    html_iframe = db.Column(db.String(255), nullable=False, index=True)

    tcp_80_isblocked = db.Column(db.Boolean, nullable=False, index=True)
    tcp_443_isblocked = db.Column(db.Boolean, nullable=False, index=True)

    client_ip = db.Column(
        db.String(16), nullable=False, index=True,
        server_default='0.0.0.0')
    client_version = db.Column(
        db.String(5), nullable=False, index=True,
        server_default='0.0.0')
    client_countrey = db.Column(
        db.String(255), nullable=False, index=True,
        server_default='default Country')
    client_city = db.Column(
        db.String(255), nullable=False, index=True,
        server_default='default City')
    client_isp = db.Column(
        db.String(255), nullable=False, index=True,
        server_default='default ISP')
    status = db.Column(
        db.Enum(*STATUS_S, name='status_statuses', native_enum=False),
        nullable=False, index=True, server_default='accessible')

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        try:
            data = self.nlocation()
            if data['city_name']:
                self.client_city = data['city_name']
            if data['country_name']:
                self.client_countrey = data['country_name']
        except:
            pass

        self.html_isblocked = self.htmlisBlocked()
        self.dns_isblocked = self.dnsisBlocked()
        if self.html_isblocked or self.dns_isblocked or self.tcp_80_isblocked:
            self.status = 'blocked'

    def json(self):
        return {'id': self.id}

    @classmethod
    def find_by_url(cls, url):
        result = ResultModel.query.filter_by(url=url)\
            .order_by(ResultModel.rdate.desc()).first()
        return result

    def location(self):
        try:
            url = 'https://freegeoip.net/json/' + self.client_ip
            r = requests.get(url)
            data = r.json()
        except:
            data = []

        return data

    def nlocation(ip):
        """
        Check the IP.

        :param ip: IPv4 IPv6
        :return: City
        """
        try:
            ipint = int(ipaddress.IPv4Address(ip))
            print(ipint)
            data = Ip4Model.find_by_ip(ipint)
            print(data.city_name)
        except Exception as e:
            print(e)
            try:
                ipint = int(ipaddress.IPv6Address(ip))
                print(ipint)
                data = Ip6Model.find_by_ip(ipint)
                print(data.city_name)
            except Exception as e:
                data = []
        return data

    def htmlisBlocked(self):
        if self.html_status == 'succeed':
            if self.html_iframe != 'None':
                regex = r"(.*10.10.34.3[4-6]*)"
                match = re.search(regex, self.html_iframe)
                if match:
                    print(1)
                    return True

            print(self.html_title)
            if self.html_title != 'None':
                regex = r"(.*10.10.34.3[4-6]*)"
                match = re.search(regex, self.html_title)
                if match:
                    return True

                regex = r"(^[A-Z][A-Z][0-9])"
                match = re.search(regex, self.html_title)
                if match:
                    return True
        else:
            print(self.html_status)
            return True

        return False

    def dnsisBlocked(self):
        if self.dns_status == 'succeed':
            regex = r"(^10.10.34.3[4-6]*)"
            match = re.search(regex, self.dns_ip)
            if match:
                return True
        else:
            return True

        return False

    @classmethod
    def all_cities(cls):
        query = db.session.query(cls.client_city.distinct().label("city"))
        cities = [row.city for row in query.all()]
        return cities

    @classmethod
    def all_results(cls):
        return cls.query.count()

    @classmethod
    def find_by_city(cls, city, limit):
        result = ResultModel.query.filter_by(client_city=city).limit(limit)
        return result
