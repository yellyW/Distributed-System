from sqlalchemy import or_, and_
from biband.extensions import db
from lib.util_sqlalchemy import ResourceMixin
# from biband.blueprints.api.models.domains import DomainModel


class Ip4Model(db.Model):
    __tablename__ = 'ip4location'

    ip_from = db.Column(db.Numeric(39, 0), unique=True, index=True, primary_key=True)
    ip_to = db.Column(db.Numeric(39, 0), unique=True, index=True, primary_key=True)
    country_code = db.Column(db.String(2), nullable=False)
    country_name = db.Column(db.String(64), nullable=False)
    region_name = db.Column(db.String(128), nullable=False)
    city_name = db.Column(db.String(128), nullable=False)

    def __init__(self, **kwargs):
        super(Ip4Model, self).__init__(**kwargs)

    @classmethod
    def find_by_ip(cls, ip):
        return Ip4Model.query.filter(and_(Ip4Model.ip_from <= ip, Ip4Model.ip_to >= ip)).first()


class Ip6Model(db.Model):
    __tablename__ = 'ip6location'

    ip_from = db.Column(db.Numeric(39, 0), unique=True, index=True, primary_key=True)
    ip_to = db.Column(db.Numeric(39, 0), unique=True, index=True, primary_key=True)
    country_code = db.Column(db.String(2), nullable=False)
    country_name = db.Column(db.String(64), nullable=False)
    region_name = db.Column(db.String(128), nullable=False)
    city_name = db.Column(db.String(128), nullable=False)

    def __init__(self, **kwargs):
        super(Ip6Model, self).__init__(**kwargs)

    @classmethod
    def find_by_ip(cls, ip):
        return Ip6Model.query.filter(and_(Ip6Model.ip_from <= ip, Ip6Model.ip_to >= ip)).first()
