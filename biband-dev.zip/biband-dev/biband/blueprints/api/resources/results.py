from flask_restful import Resource, reqparse
from flask import request
# from flask_jwt import jwt_required
from biband.blueprints.api.models.results import ResultModel
# from biband.blueprints.api.models.ip2location import Ip2LModel


class Results(Resource):
    parser = reqparse.RequestParser(bundle_errors=True)
    parser.add_argument(
        'domain_id',
        type=int,
        required=True,
        help='This field can not be left blank')

    parser.add_argument(
        'dns_status',
        type=str,
        required=True,
        help='This field can not be left blank')
    parser.add_argument(
        'dns_domain',
        type=str,
        required=True,
        help='This field can not be left blank')
    parser.add_argument(
        'dns_ip',
        type=str,
        required=True,
        help='This field can not be left blank')
    parser.add_argument(
        'dns_alter_status',
        type=str,
        required=True,
        help='This field can not be left blank')
    parser.add_argument(
        'dns_alter_domain',
        type=str,
        required=True,
        help='This field can not be left blank')
    parser.add_argument(
        'dns_alter_ip',
        type=str,
        required=True,
        help='This field can not be left blank')

    parser.add_argument(
        'html_status',
        type=str,
        required=True,
        help='This field can not be left blank')
    parser.add_argument(
        'html_status_code',
        type=int,
        help='This field can not be left blank')
    parser.add_argument(
        'html_headers',
        type=str,
        help='This field can not be left blank')
    parser.add_argument(
        'html_title',
        type=str,
        required=True,
        help='This field can not be left blank')
    parser.add_argument(
        'html_iframe',
        type=str,
        required=True,
        help='This field can not be left blank')

    parser.add_argument(
        'tcp_80_isblocked',
        type=bool,
        required=True,
        help='This field can not be left blank')
    parser.add_argument(
        'tcp_443_isblocked',
        type=bool,
        required=True,
        help='This field can not be left blank')

    parser.add_argument(
        'client_version',
        type=str,
        required=True,
        help='This field can not be left blank')

    # parser.add_argument(
    #     'client_ip',
    #     type=str,
    #     required=True,
    #     help='This field can not be left blank')

    # @jwt_required()
    def post(self):
        data = Results.parser.parse_args()
        data['client_ip'] = str(request.remote_addr)
        # print(request.remote_addr)
        result = ResultModel(**data)

        try:
            result.save()
        except Exception as e:
            print(e)
            return {'message': 'An error occurred inserting the item.'}, 500
        return result.json(), 201
