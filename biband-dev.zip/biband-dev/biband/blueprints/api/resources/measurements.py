from flask_restful import Resource, reqparse
# from flask_jwt import jwt_required
# from flask import current_app as app
from biband.blueprints.measurement.models import DomainInsight
# from biband.blueprints.api.models.categories import CatModel
import json
from lib.util_json import MyEncoder


class Measurement(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument(
        'n',
        type=int,
        required=True,
        help='This field can not be left blank')
    parser.add_argument(
        'cat',
        type=int,
        required=False,
        help='This field can not be left blank')
    parser.add_argument(
        'id',
        type=int,
        required=True,
        help='This field can not be left blank')
    parser.add_argument(
        'd',
        type=int,
        required=True,
        help='This field can not be left blank')

    def row2dict(row):
        d = {}
        for column in row.__table__.columns:
            d[column.name] = str(getattr(row, column.name))

        return d

    # @jwt_required()
    def post(self):
        data = Measurement.parser.parse_args()
        measurements = []

        if data['cat']:
            # print(data['cat'])
            measurementsq = DomainInsight.find_latest_by_cat(data['n'], data['cat'])
            for row in measurementsq:
                item = {"id": row.id}
                # item = Measurement.row2dict(row)
                measurements.append(item)
        # else:
        #     measurementsq = DomainInsight.find_latest(data['n'])
        #     for row in measurementsq:
        #         # item = {"id": measurement.id}
        #         item = Measurement.row2dict(row)
        #         measurements.append(item)
        else:
            measurementsq = DomainInsight.find_all_by_id(data['id'], data['d'])
            for row in measurementsq:
                # item = {"id": row.id, "dns": row.dns_ip, "date": json.dumps(row.created_on, cls=MyEncoder)}
                item = {"id": row.id, "dns": row.dns_ip, "date": row.created_on.strftime("%d-%m-%Y")}
                # item = Measurement.row2dict(row)
                measurements.append(item)

        return {"measurements": measurements}, 200
