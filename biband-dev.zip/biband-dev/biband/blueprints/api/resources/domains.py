from flask_restful import Resource, reqparse
# from flask_jwt import jwt_required
# from flask import current_app as app
from biband.blueprints.api.models.domains import DomainModel, DomainSample
# from biband.blueprints.api.models.categories import CatModel


class Domain(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument(
        'url',
        type=str,
        required=True,
        help='This field can not be left blank')
    parser.add_argument(
        'priority',
        type=int,
        required=True,
        help='This field can not be left blank')
    parser.add_argument(
        'cat',
        type=str,
        required=True,
        help='This field can not be left blank')

    # @jwt_required()
    def post(self):
        data = Domain.parser.parse_args()

        domain = DomainModel.find_by_url(data['url'])
        if domain:
            return {'message': 'This domain has been already added.'}, 400
        domain = DomainModel(data['url'], data['priority'], data['cat'])

        try:
            domain.save()
        except:
            return {'message': 'An error occurred inserting the item.'}, 500
        return domain.json(), 201

    def get(self):

        domains = []

        # categories = CatModel.getall()
        # for cat in categories:
        #     for priority in app.config['PRIORITIES']:
        #         domainq = DomainSample.getrandom(
        #             cat.id, priority, app.config['PRIORITIES_QTY'][priority])
        #         for domain in domainq:
        #             item = {
        #                 "id": domain.id,
        #                 "url": domain.url,
        #                 "ip": domain.ip}
        #             domains.append(item)

        # manual
        domainq = DomainSample.getrandom('1', '4', 20)
        for domain in domainq:
            item = {"id": domain.id, "url": domain.url, "ip": domain.ip}
            domains.append(item)

        return {"domains": domains}, 200
