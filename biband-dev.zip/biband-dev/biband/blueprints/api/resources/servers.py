from flask_restful import Resource, reqparse
from flask import request
from flask_jwt import jwt_required
from biband.blueprints.admin.optionmodels import Options
import json


class Server(Resource):

    @jwt_required()
    def post(self):
        content = request.get_json()
        servers = Options().get('servers')
        if servers:
            print(servers.value)
            servers.value = json.dumps(content)
            servers.save()
        else:
            servers = Options(name='servers', value=json.dumps(content))
            servers.save()

        return 'done', 201

    def get(self):
        servers = Options().get('servers')
        if servers:
            return json.loads(servers.value), 200
