from flask import Blueprint
from flask_restful import Api
from biband.blueprints.api.myapi import MyApi
# from flask_jwt import JWT
# from biband.blueprints.api.models.user import UserModel
# from biband.blueprints.api.resources.user import UserRegister
# from biband.blueprints.api.resources.url import Url
# from biband.blueprints.api.resources.confirm import Confirm
from biband.blueprints.api.resources.domains import Domain
from biband.blueprints.api.resources.results import Results
from biband.blueprints.api.resources.measurements import Measurement
from biband.blueprints.api.resources.servers import Server
# from lib.util_error import handle_user_exception_again


api_bp = Blueprint('biband_api', __name__, url_prefix='/api/v1.0')


api = MyApi()
api.init_app(api_bp)

# api.handle_user_exception = handle_user_exception_again

api.add_resource(Domain, '/domain')
api.add_resource(Results, '/result')
api.add_resource(Measurement, '/measurement')
api.add_resource(Server, '/server')
