from flask_restful import Api
from flask_jwt import JWTError
from collections import OrderedDict
import jsonify


class MyApi(Api):
    """A simple class to keep the default flask_jwt.JWTError behaviour."""

    def handle_error(self, e):
        if isinstance(e, JWTError):
            return jsonify(
                OrderedDict([
                    ('status_code', e.status_code),
                    ('error', e.error),
                    ('description', e.description),
                ])
            ), e.status_code, e.headers
        return super(MyApi, self).handle_error(e)
