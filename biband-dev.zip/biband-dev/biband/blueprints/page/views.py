from flask import Blueprint, render_template
from flask import request, send_from_directory
from biband.blueprints.measurement.forms import SearchForm

page = Blueprint('page', __name__, template_folder='templates')


@page.route('/')
def home():
    search_form = SearchForm()
    return render_template(
        'page/home.html',
        form=search_form)


@page.route('/terms')
def terms():
    return render_template('page/terms.html')


@page.route('/privacy')
def privacy():
    return render_template('page/privacy.html')


@page.route('/about')
def about():
    return render_template('page/about.html')


@page.route('/download')
def download():
    return render_template('page/download.html')


@page.route('/help')
def help():
    return render_template('page/help.html')


@page.route('/robots.txt')
@page.route('/sitemap.xml')
def static_from_root():
    return send_from_directory('static', request.path[1:])
