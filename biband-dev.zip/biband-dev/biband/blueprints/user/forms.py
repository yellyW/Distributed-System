from flask_wtf import FlaskForm
from wtforms import HiddenField, StringField, PasswordField, TextAreaField
from wtforms.validators import DataRequired, Length, Optional, Regexp
from wtforms_components import EmailField, Email
from wtforms_alchemy import Unique
from flask_wtf.recaptcha import RecaptchaField

from lib.util_wtforms import ModelForm
from biband.blueprints.user.models import User, db
from biband.blueprints.user.validations import ensure_identity_exists, \
    ensure_existing_password_matches


class LoginForm(FlaskForm):
    next = HiddenField()
    identity = StringField('Username or email:',
                           [DataRequired(), Length(3, 254)])
    password = PasswordField('Password:', [DataRequired(), Length(8, 128)])
    recaptcha = RecaptchaField()
    # remember = BooleanField('Stay signed in')


class BeginPasswordResetForm(FlaskForm):
    identity = StringField('Username or email:',
                           [DataRequired(),
                            Length(3, 254),
                            ensure_identity_exists])
    recaptcha = RecaptchaField()


class PasswordResetForm(FlaskForm):
    reset_token = HiddenField()
    password = PasswordField('Password', [DataRequired(), Length(8, 128)])


class SignupForm(ModelForm):
    username_message = 'Letters, numbers and underscores only please.'
    email = EmailField('Email address:', validators=[
        DataRequired(),
        Email(),
        Unique(
            User.email,
            get_session=lambda: db.session
        )
    ])
    password = PasswordField('Password:', [DataRequired(), Length(8, 128)])
    recaptcha = RecaptchaField()

    username = StringField('Name:', validators=[
        Unique(
            User.username,
            get_session=lambda: db.session
        ),
        DataRequired(),
        Length(3, 28),
        Regexp('^\w+$', message=username_message)
    ])


class WelcomeForm(ModelForm):
    username_message = 'Letters, numbers and underscores only please.'

    username = StringField(validators=[
        Unique(
            User.username,
            get_session=lambda: db.session
        ),
        DataRequired(),
        Length(3, 28),
        Regexp('^\w+$', message=username_message)
    ])


class UpdateCredentials(ModelForm):
    password = PasswordField(
        'Current password',
        [DataRequired(),
            Length(8, 128),
            ensure_existing_password_matches])

    email = EmailField(validators=[
        Email(),
        Unique(
            User.email,
            get_session=lambda: db.session
        )
    ])
    new_password = PasswordField('Password', [Optional(), Length(8, 128)])


class ProfileForm(ModelForm):
    password = PasswordField(
        'Current password',
        [DataRequired(),
            Length(8, 128),
            ensure_existing_password_matches])

    username_message = 'Letters, numbers and underscores only please.'

    username = StringField(validators=[
        Unique(
            User.username,
            get_session=lambda: db.session
        ),
        DataRequired(),
        Length(3, 28),
        Regexp('^\w+$', message=username_message)
    ])

    email = EmailField(validators=[
        Email(),
        Unique(
            User.email,
            get_session=lambda: db.session
        )
    ])

    new_password = PasswordField('Password', [Optional(), Length(8, 128)])

    bio = TextAreaField('Bio', [Optional(), Length(0, 254)])
