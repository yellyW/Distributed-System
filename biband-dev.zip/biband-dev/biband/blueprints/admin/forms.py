from collections import OrderedDict
from flask_wtf import FlaskForm
from wtforms import SelectField, StringField, BooleanField
from wtforms.validators import DataRequired, Length, Optional, Regexp, URL
# from wtforms_components import Unique
from wtforms_components import EmailField, Email
from wtforms_alchemy import Unique

from lib.util_wtforms import ModelForm, choices_from_dict, check_backslash
from biband.blueprints.user.models import db, User
from biband.blueprints.api.models.domains import DomainModel
from biband.blueprints.api.models.categories import CatModel
from biband.blueprints.admin.optionmodels import Options


class SearchForm(FlaskForm):
    q = StringField('Search terms', [Optional(), Length(1, 256)])


class SearchFormDomain(FlaskForm):
    q = StringField(
        'Domain',
        [Optional(), Length(1, 256)])

    pr = SelectField(
        'Priority',
        [DataRequired()],
        choices=choices_from_dict(
            DomainModel.PRIORITY,
            prepend_blank=False),
        coerce=int,
        default=4)

    cat_id = SelectField(
        'Category',
        [DataRequired()],
        coerce=int,
        default=1)


class BulkDeleteForm(FlaskForm):
    SCOPE = OrderedDict([
        ('all_selected_items', 'All selected items'),
        ('all_search_results', 'All search results')
    ])

    scope = SelectField('Privileges', [DataRequired()],
                        choices=choices_from_dict(SCOPE, prepend_blank=False))


class UserForm(ModelForm):
    username_message = 'Letters, numbers and underscores only please.'

    username = StringField('Username', validators=[
        Unique(
            User.username,
            get_session=lambda: db.session
        ),
        Optional(),
        Length(1, 16),
        Regexp('^\w+$', message=username_message)
    ])

    email = EmailField('Email address', validators=[
        DataRequired(),
        Email(),
        Optional(),
        Unique(
            User.email,
            get_session=lambda: db.session
        )
    ])

    role = SelectField(
        'Privileges',
        [DataRequired()],
        choices=choices_from_dict(
            User.ROLE,
            prepend_blank=False))
    active = BooleanField('Activate the user')


def enabled_category():
    return lambda: db.session.query(CatModel)


def default_category():
    return lambda: db.session.query(CatModel).filter_by(id=2).first()


class DomainForm(ModelForm):
    url_message = 'Use URL format: http(s)://subdomain.example.com'
    url = StringField(
        validators=[
            Unique(
                DomainModel.url,
                get_session=lambda: db.session
            ),
            check_backslash,
            URL()
        ])

    priority = SelectField(
        'Priority', [DataRequired()],
        choices=choices_from_dict(
            DomainModel.PRIORITY,
            prepend_blank=False), default=4)

    cat_id = SelectField('Category', [DataRequired()], coerce=int, default=1)
    cat_id2 = SelectField('Category', [DataRequired()], coerce=int, default=1)
    cat_id3 = SelectField('Category', [DataRequired()], coerce=int, default=1)

    active = BooleanField(
        'Yes, send this domain to client for check.',
        default=True)


class CategoryForm(ModelForm):
    name_message = 'choose a name less than 128 characters'

    name = StringField(validators=[
        Unique(
            CatModel.name,
            get_session=lambda: db.session
        )
    ])


class OptionForm(ModelForm):
    name_message = 'Letters, numbers and underscores only please.'

    name = StringField(validators=[
        Unique(
            Options.name,
            get_session=lambda: db.session
        ),
        Length(1, 128),
        Regexp('^\w+$', message=name_message)
    ])

    value = StringField(validators=[
        DataRequired()
    ])

