from sqlalchemy import or_, text
from sqlalchemy import func, desc, asc
from biband.blueprints.user.models import db, User
from biband.blueprints.api.models.domains import DomainModel
from biband.blueprints.api.models.results import ResultModel
from lib.util_sqlalchemy import ResourceMixin


class Dashboard(object):
    @classmethod
    def group_and_count_users(cls):
        """
        Perform a group by/count on all users.

        :return: dict
        """
        return Dashboard._group_and_count(User, User.role)

    @classmethod
    def group_domains_cat(cls):
        return Dashboard._group_and_count(DomainModel, DomainModel.cat_id)

    @classmethod
    def group_domains_pr(cls):
        return Dashboard._group_and_count(DomainModel, DomainModel.priority)

    @classmethod
    def blocked_domains(cls):
        return Dashboard._result_filter_and_count(
            ResultModel, ResultModel.status, 'blocked',
            ResultModel.domain_id)

    @classmethod
    def all_results(cls):
        return Dashboard._results_group_and_count(
            ResultModel, ResultModel.domain_id)

    @classmethod
    def _group_and_count(cls, model, field):
        """
        Group results for a specific model and field.

        :param model: Name of the model
        :type model: SQLAlchemy model
        :param field: Name of the field to group on
        :type field: SQLAlchemy field
        :return: dict
        """
        count = func.count(field)
        query = db.session.query(count, field).group_by(field).all()

        results = {
            'query': query,
            'total': model.query.count()
        }

        return results

    @classmethod
    def _result_filter_and_count(cls, model, field, filter, gfield):
        count = func.count(field)
        query = db.session.query(count, field, gfield)\
            .filter_by(status=filter).group_by(gfield, field).all()
        count2 = db.session.query(field, count, gfield)\
            .filter_by(status=filter).group_by(field, gfield).count()

        results = {
            'query': query,
            'total': count2
        }

        return results

    @classmethod
    def _results_group_and_count(cls, model, field):
        count = func.count(field)
        query = db.session.query(count, field).group_by(field).all()
        count2 = db.session.query(field, count).group_by(field).count()

        results = {
            'query': query,
            'total': count2
        }

        return results
