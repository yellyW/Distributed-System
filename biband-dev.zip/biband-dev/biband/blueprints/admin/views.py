from flask import (
    Blueprint,
    redirect,
    request,
    flash,
    abort,
    render_template)
# from flask import current_app
from flask_login import login_required, current_user
from sqlalchemy import text

from biband.blueprints.admin.optionmodels import Options
from biband.blueprints.user.decorators import role_required, role_prohibited
from biband.blueprints.api.models.domains import DomainModel
from biband.blueprints.api.models.categories import CatModel
from biband.blueprints.measurement.models import ResultInsight, DomainInsight
from biband.blueprints.user.models import User
from biband.blueprints.admin.forms import (
    SearchForm,
    SearchFormDomain,
    BulkDeleteForm,
    UserForm,
    DomainForm,
    CategoryForm,
    OptionForm
)
from lib.util_urlfor import get_url
from pprint import pprint


admin = Blueprint('admin', __name__,
                  template_folder='templates', url_prefix='/admin')


@admin.before_request
@login_required
@role_required('admin', 'editor')
def before_request():
    """ Protect all of the admin endpoints. """
    pass


# Dashboard -------------------------------------------------------------------
# @admin.route('')
@admin.route('', defaults={'page': 1}, methods=['GET'])
@admin.route('/page/<int:page>', methods=['GET'])
def dashboard(page):
    # group_and_count_users = Dashboard.group_and_count_users()
    # group_domains_cat = Dashboard.group_domains_cat()
    # group_domains_pr = Dashboard.group_domains_pr()
    # blocked_domains = Dashboard.blocked_domains()
    # all_results = Dashboard.all_results()

    totaldomains = ResultInsight.find_by_name('total', 'totaldomain')
    totalresults = ResultInsight.find_by_name('total', 'totalresult')
    inactivedomain = ResultInsight.find_by_name('total', 'inactivedomain')
    totlauser = User.get_last_id()

    categories = CatModel.getlist()

    rows_query = Options.get('rows_qty')
    if hasattr(rows_query, 'value'):
        rows_qty = int(rows_query.value)
    else:
        rows_qty = 10

    sort_by = DomainModel.sort_by(
        request.args.get('sort', 'category'),
        request.args.get('direction', 'desc'))
    order_values = '{0} {1}'.format(sort_by[0], sort_by[1])

    paginated_domains = DomainModel.query \
        .filter(DomainModel.active.is_(False)) \
        .order_by(text(order_values)) \
        .paginate(page, rows_qty, True)

    return render_template('admin/page/dashboard3.html',
                           # group_and_count_users=group_and_count_users,
                           # group_domains_cat=group_domains_cat,
                           # group_domains_pr=group_domains_pr,
                           # blocked_domains=blocked_domains,
                           # all_results=all_results,
                           domains=paginated_domains,
                           totaldomains=totaldomains,
                           totalresults=totalresults,
                           totlauser=totlauser,
                           inactivedomain=inactivedomain,
                           categories=categories
                           )


# Users Ajax -----------------------------------------------------------------
@admin.route(
    '/users_ajax',
    defaults={'page': 1},
    methods=['GET', 'POST'],
    strict_slashes=False)
@admin.route(
    '/users_ajax/page/<int:page>',
    methods=['GET', 'POST'],
    strict_slashes=False)
@role_prohibited('editor')
def users_ajax(page):
    search_form = SearchForm()
    bulk_form = BulkDeleteForm()

    role_index = ['', 'admin', 'member', 'editor']

    sort_by = User.sort_by(
        request.args.get('sort', 'created_on'),
        request.args.get('direction', 'desc'))
    order_values = '{0} {1}'.format(sort_by[0], sort_by[1])

    if request.form.get('q', '', type=str):
        q = request.form.get('q', '', type=str)
    elif request.args.get('q', '', type=str):
        q = request.args.get('q', '', type=str)
    else:
        q = ''

    try:
        urole = int(request.args.get('urole'))
    except Exception:
        abort(404)

    if 1 <= urole <= 3:
        paginated_users = User.query \
            .filter(User.search(q)) \
            .filter(User.role == role_index[urole]) \
            .order_by(User.role.asc(), text(order_values)) \
            .paginate(page, 10, True)
    else:
        paginated_users = User.query \
            .filter(User.search(q)) \
            .order_by(User.role.asc(), text(order_values)) \
            .paginate(page, 10, True)

    return render_template('admin/user/user_table.html',
                           form=search_form, bulk_form=bulk_form,
                           users=paginated_users)


# Users -----------------------------------------------------------------------
@admin.route(
    '/users',
    defaults={'page': 1},
    methods=['GET'],
    strict_slashes=False)
@admin.route(
    '/users/page/<int:page>',
    methods=['GET'],
    strict_slashes=False)
@role_prohibited('editor')
def users(page):
    search_form = SearchForm()
    bulk_form = BulkDeleteForm()

    sort_by = User.sort_by(
        request.args.get('sort', 'created_on'),
        request.args.get('direction', 'desc'))
    order_values = '{0} {1}'.format(sort_by[0], sort_by[1])

    # if request.form.get('q', '', type=str):
    #     q = request.form.get('q', '', type=str)
    if request.args.get('q', '', type=str):
        q = request.args.get('q', '', type=str)
    else:
        q = ''

    rows_query = Options.get('rows_qty')
    if hasattr(rows_query, 'value'):
        rows_qty = int(rows_query.value)
    else:
        rows_qty = 10

    paginated_users = User.query \
        .filter(User.search(q)) \
        .order_by(User.role.asc(), text(order_values)) \
        .paginate(page, rows_qty, True)

    total_users = User.query \
        .filter(User.search(q)).count()

    paginated_admins = User.query \
        .filter(User.search(q)) \
        .filter(User.role == 'admin') \
        .order_by(text(order_values)) \
        .paginate(page, rows_qty, True)

    total_admins = User.query \
        .filter(User.search(q)) \
        .filter(User.role == 'admin').count()

    paginated_eitors = User.query \
        .filter(User.search(q)) \
        .filter(User.role == 'editor') \
        .order_by(text(order_values)) \
        .paginate(page, rows_qty, True)

    total_eitors = User.query \
        .filter(User.search(q)) \
        .filter(User.role == 'editor').count()

    paginated_members = User.query \
        .filter(User.search(q)) \
        .filter(User.role == 'member') \
        .order_by(text(order_values)) \
        .paginate(page, rows_qty, True)

    total_members = User.query \
        .filter(User.search(q)) \
        .filter(User.role == 'member').count()

    return render_template(
        'admin/user/index_dash.html',
        form=search_form,
        bulk_form=bulk_form,
        users=paginated_users,
        total_users=total_users,
        admins=paginated_admins,
        total_admins=total_admins,
        eitors=paginated_eitors,
        total_eitors=total_eitors,
        members=paginated_members,
        total_members=total_members)


@admin.route(
    '/users/edit/<int:id>',
    methods=['GET', 'POST'],
    strict_slashes=False)
@role_prohibited('editor')
def users_edit(id):
    user = User.query.get(id)
    form = UserForm(obj=user)

    if form.validate_on_submit():
        if User.is_last_admin(user,
                              request.form.get('role'),
                              request.form.get('active')):
            flash('You are the last admin, you cannot do that.', 'error')
            return redirect(get_url('admin.users'))

        form.populate_obj(user)

        if not user.username:
            user.username = None

        user.save()

        flash('User has been saved successfully.', 'success')
        return redirect(get_url('admin.users'))

    return render_template(
        'admin/user/edit_dash.html',
        form=form,
        user=user)


@admin.route(
    '/users/bulk_delete',
    methods=['POST'],
    strict_slashes=False)
@role_prohibited('editor')
def users_bulk_delete():
    form = BulkDeleteForm()

    if form.validate_on_submit():
        ids = User.get_bulk_action_ids(request.form.get('scope'),
                                       request.form.getlist('bulk_ids'),
                                       omit_ids=[current_user.id],
                                       query=request.args.get('q', ''))

        delete_count = User.bulk_delete(ids)

        flash('{0} user(s) were scheduled to be deleted.'.format(delete_count),
              'success')
    else:
        flash('No users were deleted, something went wrong.', 'error')

    return redirect(get_url('admin.users'))


@admin.route(
    '/users/new',
    methods=['GET', 'POST'],
    strict_slashes=False)
@role_prohibited('editor')
def users_new():
    form = UserForm(request.form)

    if form.validate_on_submit():
        user = User()
        # if User.is_last_admin(user,
        #                       request.form.get('role'),
        #                       request.form.get('active')):
        #     flash('You are the last admin, you cannot do that.', 'error')
        #     return redirect(get_url('admin.users'))

        form.populate_obj(user)

        if not user.username:
            user.username = None

        user.save()

        flash('User has been saved successfully.', 'success')
        return redirect(get_url('admin.users'))

    return render_template('admin/user/new_dash.html', form=form)


# domains --------------------------------------------------------
@admin.route(
    '/domains',
    defaults={'page': 1},
    methods=['GET'],
    strict_slashes=False)
@admin.route(
    '/domains/page/<int:page>',
    methods=['GET'],
    strict_slashes=False)
def domains(page):
    search_form = SearchFormDomain()
    search_form.cat_id.choices = [(g.id, g.name) for g in CatModel.getall()]

    bulk_form = BulkDeleteForm()

    totaldomain = ResultInsight.find_by_name('total', 'totaldomain')
    inactivedomain = ResultInsight.find_by_name('total', 'inactivedomain')
    nottestedtotal = ResultInsight.find_by_name('total', 'nottestedtotal')
    notcattotal = ResultInsight.find_by_name('total', 'notcattotal')
    notiptotal = ResultInsight.find_by_name('total', 'notiptotal')

    sort_by = DomainModel.sort_by(
        request.args.get('sort', 'category'),
        request.args.get('direction', 'desc'))
    order_values = '{0} {1}'.format(sort_by[0], sort_by[1])

    # if request.form.get('q', '', type=str):
    #     q = request.form.get('q', '', type=str)
    if request.args.get('q', '', type=str):
        q = request.args.get('q', '', type=str)
        search_form.q.data = q
    else:
        q = ''

    # if request.form.get('cat_id', '', type=int):
    #     cat_id = request.form.get('cat_id', '', type=int)
    if request.args.get('cat_id', '', type=int):
        cat_id = request.args.get('cat_id', '', type=int)
        search_form.cat_id.data = cat_id
    else:
        cat_id = ''

    # if request.form.get('pr', '', type=int):
    #     pr = request.form.get('pr', '', type=int)
    if request.args.get('pr', '', type=int):
        pr = request.args.get('pr', '', type=int)
        search_form.pr.data = pr
    else:
        pr = ''

    categories = CatModel.getlist()

    rows_query = Options.get('rows_qty')
    if hasattr(rows_query, 'value'):
        rows_qty = int(rows_query.value)
    else:
        rows_qty = 10

    paginated_domains = DomainModel.query \
        .filter(DomainModel.search(q)) \
        .filter(DomainModel.filter_cat(cat_id)) \
        .filter(DomainModel.filter_priority(pr)) \
        .order_by(text(order_values)) \
        .paginate(page, rows_qty, False)

    paginated_inactive_domains = DomainModel.query \
        .filter(DomainModel.active.is_(False)) \
        .filter(DomainModel.search(q)) \
        .filter(DomainModel.filter_cat(cat_id)) \
        .filter(DomainModel.filter_priority(pr)) \
        .order_by(text(order_values)) \
        .paginate(page, rows_qty, False)

    return render_template(
        'admin/domain/index_dash.html',
        form=search_form,
        bulk_form=bulk_form,
        domains=paginated_domains,
        inactive_domains=paginated_inactive_domains,
        categories=categories,
        totaldomain=totaldomain,
        inactivedomain=inactivedomain,
        nottestedtotal=nottestedtotal,
        notcattotal=notcattotal,
        notiptotal=notiptotal,
        alldomainstab=True)


@admin.route(
    '/domains/edit/<int:id>',
    methods=['GET', 'POST'],
    strict_slashes=False)
def domains_edit(id):

    next = request.args.get("next", type=str)
    if next is None:
        # print('Got None')
        next = "default"
    # print(next)

    domain = DomainModel.query.get(id)
    form = DomainForm(obj=domain)
    form.cat_id.choices = [(g.id, g.name) for g in CatModel.getall()]
    form.cat_id2.choices = [(g.id, g.name) for g in CatModel.getall()]
    form.cat_id3.choices = [(g.id, g.name) for g in CatModel.getall()]

    # current_app.logger.debug(
    #         '{0} is the category'.format(form.cat_id.default))
    # current_app.logger.debug(
    #         '{0} is the category'.format(form.cat_id.object_data))
    if current_user.role == 'editor':
        del form.url

    if form.validate_on_submit():

        form.populate_obj(domain)
        domain.cat_id = form.cat_id.data
        domain.cat_id2 = form.cat_id2.data
        domain.cat_id3 = form.cat_id3.data

        try:
            domain.save_ip()
            flash('Domain has been saved successfully.', 'success')
            if next == 'dashboard':
                print(next)
                return redirect(get_url('admin.dashboard'))
            else:
                return redirect(get_url('admin.domains'))
        except Exception as e:
            print(e)
            flash('There was an error. check the url.', 'error')

    return render_template(
        'admin/domain/edit_dash.html',
        form=form,
        domain=domain)


@admin.route(
    '/domains/bulk_delete',
    methods=['POST'],
    strict_slashes=False)
@role_prohibited('editor')
def domains_bulk_delete():
    form = BulkDeleteForm()

    if form.validate_on_submit():
        ids = DomainModel.get_bulk_action_ids(
            request.form.get('scope'),
            request.form.getlist('bulk_ids'),
            # omit_ids=[current_user.id],
            query=request.args.get('q', ''))

        delete_domain = DomainModel.bulk_delete(ids)

        flash(
            '{0} domain(s) were scheduled to be deleted.'
            .format(delete_domain),
            'success')
    else:
        flash('No domains were deleted, something went wrong.', 'error')

    return redirect(get_url('admin.domains'))


@admin.route(
    '/domains/new',
    methods=['GET', 'POST'],
    strict_slashes=False)
def domains_new():
    form = DomainForm(request.form)
    form.cat_id.choices = [(g.id, g.name) for g in CatModel.getall()]
    form.cat_id2.choices = [(g.id, g.name) for g in CatModel.getall()]
    form.cat_id3.choices = [(g.id, g.name) for g in CatModel.getall()]

    if form.validate_on_submit():
        domain = DomainModel()

        form.populate_obj(domain)
        domain.cat_id = form.cat_id.data
        domain.cat_id2 = form.cat_id2.data
        domain.cat_id3 = form.cat_id3.data

        try:
            domain.save_ip()
            flash('Domain has been saved successfully.', 'success')
            return redirect(get_url('admin.domains_new'))
        except Exception as e:
            print(e)
            flash('There was an error. check the url.', 'error')

    return render_template('admin/domain/new_dash.html', form=form)


# categories -------------------------------------------------------------
@admin.route(
    '/categories',
    defaults={'page': 1},
    methods=['GET'],
    strict_slashes=False)
@admin.route(
    '/categories/page/<int:page>',
    methods=['GET'],
    strict_slashes=False)
def categories(page):
    search_form = SearchForm()
    bulk_form = BulkDeleteForm()

    sort_by = CatModel.sort_by(
        request.args.get('sort', 'created_on'),
        request.args.get('direction', 'desc'))
    order_values = '{0} {1}'.format(sort_by[0], sort_by[1])

    # if request.form.get('q', '', type=str):
    #     q = request.form.get('q', '', type=str)
    if request.args.get('q', '', type=str):
        q = request.args.get('q', '', type=str)
    else:
        q = ''

    rows_query = Options.get('rows_qty')
    if hasattr(rows_query, 'value'):
        rows_qty = int(rows_query.value)
    else:
        rows_qty = 10

    paginated_categories = CatModel.query \
        .filter(CatModel.search(q)) \
        .order_by(text(order_values)) \
        .paginate(page, rows_qty, True)

    domainqty = CatModel.getdomainscount()

    total = CatModel.total()

    return render_template(
        'admin/category/index_dash.html',
        form=search_form,
        bulk_form=bulk_form,
        categories=paginated_categories,
        domainqty=domainqty,
        total=total)


@admin.route(
    '/categories/edit/<int:id>',
    methods=['GET', 'POST'],
    strict_slashes=False)
def categories_edit(id):
    category = CatModel.query.get(id)
    form = CategoryForm(obj=category)

    if form.validate_on_submit():

        form.populate_obj(category)

        try:
            category.save()
            flash('Category has been saved successfully.', 'success')
            return redirect(get_url('admin.categories'))
        except Exception as e:
            print(e)
            flash('There was an error. check the name.', 'error')

    return render_template(
        'admin/category/edit_dash.html',
        form=form,
        category=category)


@admin.route(
    '/categories/new',
    methods=['GET', 'POST'],
    strict_slashes=False)
def categories_new():
    form = CategoryForm(request.form)

    if form.validate_on_submit():
        category = CatModel()

        form.populate_obj(category)
        # current_app.logger.debug(
        #                 '{0} is the name of new category'
        #                 .format(category.name))

        try:
            category.save()
            flash('Category has been saved successfully.', 'success')
            return redirect(get_url('admin.categories_new'))
        except Exception as e:
            print(e)
            flash('There was an error. check the name.', 'error')

    return render_template('admin/category/new_dash.html', form=form)


# options -------------------------------------------------------------
@admin.route(
    '/options',
    defaults={'page': 1},
    methods=['GET'],
    strict_slashes=False)
@admin.route(
    '/options/page/<int:page>',
    methods=['GET'],
    strict_slashes=False)
@role_prohibited('editor')
def options(page):
    search_form = SearchForm()

    sort_by = Options.sort_by(
        request.args.get('sort', 'created_on'),
        request.args.get('direction', 'desc'))
    order_values = '{0} {1}'.format(sort_by[0], sort_by[1])

    # if request.form.get('q', '', type=str):
    #     q = request.form.get('q', '', type=str)
    if request.args.get('q', '', type=str):
        q = request.args.get('q', '', type=str)
    else:
        q = ''

    rows_query = Options.get('rows_qty')
    if hasattr(rows_query, 'value'):
        rows_qty = int(rows_query.value)
    else:
        rows_qty = 10

    paginated_options = Options.query \
        .filter(Options.search(q)) \
        .order_by(text(order_values)) \
        .paginate(page, rows_qty, True)

    return render_template(
        'admin/option/index_dash.html',
        form=search_form,
        options=paginated_options)


@admin.route(
    '/options/edit/<int:id>',
    methods=['GET', 'POST'],
    strict_slashes=False)
@role_prohibited('editor')
def options_edit(id):
    option = Options.query.get(id)
    form = OptionForm(obj=option)

    if form.validate_on_submit():

        form.populate_obj(option)

        try:
            option.save()
            flash('Category has been saved successfully.', 'success')
            return redirect(get_url('admin.options'))
        except Exception as e:
            print(e)
            flash('There was an error. check the name.', 'error')

    return render_template(
        'admin/option/edit_dash.html',
        form=form,
        option=option)


@admin.route(
    '/options/new',
    methods=['GET', 'POST'],
    strict_slashes=False)
@role_prohibited('editor')
def options_new():
    form = OptionForm(request.form)

    if form.validate_on_submit():
        option = Options()

        form.populate_obj(option)
        # current_app.logger.debug(
        #                 '{0} is the name of new Option'
        #                 .format(option.name))

        try:
            option.save()
            flash('Category has been saved successfully.', 'success')
            return redirect(get_url('admin.options'))
        except Exception as e:
            print(e)
            flash('There was an error. check the name.', 'error')

    return render_template('admin/option/new_dash.html', form=form)
