from sqlalchemy import or_, text
from biband.blueprints.user.models import db
from lib.util_sqlalchemy import ResourceMixin


class Options(ResourceMixin, db.Model):
    """docstring for Options"""
    __tablename__ = 'options'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128), unique=True)
    value = db.Column(db.String(255), unique=True, nullable=False,
                      server_default='')

    def __init__(self, **kwargs):
        super(Options, self).__init__(**kwargs)

    @classmethod
    def get(cls, name):
        return Options.query.filter_by(name=name).first()

    @classmethod
    def search(cls, query):
        """
        Search an option by Name or Value
        """
        if not query:
            return text('')

        search_query = '%{0}%'.format(query)
        search_chain = (Options.name.ilike(search_query),
                        Options.value.ilike(search_query))

        return or_(*search_chain)
