from flask_wtf import FlaskForm
from wtforms import TextAreaField
from wtforms_components import EmailField
from wtforms.validators import DataRequired, Length
from flask_wtf.recaptcha import RecaptchaField


class ContactForm(FlaskForm):
    email = EmailField("Email address:",
                       [DataRequired(), Length(3, 254)])
    message = TextAreaField("Message:",
                            [DataRequired(), Length(1, 8192)])
    recaptcha = RecaptchaField()
