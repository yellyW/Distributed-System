from biband.blueprints.contact.views import contact
