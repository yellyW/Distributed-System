import logging
# import os
from flask import Flask, render_template
from celery import Celery
from werkzeug.contrib.fixers import ProxyFix
from flask_jwt import JWT
from lib.security import authenticate, identity
# from logging.handlers import SMTPHandler

from biband.blueprints.user.models import User
from biband.blueprints.page import page
# from biband.blueprints.search import search
from biband.blueprints.user import user
from biband.blueprints.admin import admin
from biband.blueprints.contact import contact
from biband.blueprints.api import api_bp
from biband.blueprints.measurement import measurement
from biband.extensions import db, mail, login_manager, htmlmin
from lib.util_urlfor import get_url, get_static_url, get_url_clear
from raven.contrib.flask import Sentry


CELERY_TASK_LIST = [
    'biband.blueprints.contact.tasks',
    'biband.blueprints.user.tasks',
]


def create_celery_app(app=None):
    """
    Create a new Celery object and tie together the Celery config to the app's
    config. Wrap all tasks in the context of the application.

    :param app: Flask app
    :return: Celery app
    """
    app = app or create_app()

    celery = Celery(app.import_name, broker=app.config['CELERY_BROKER_URL'],
                    include=CELERY_TASK_LIST)
    celery.conf.update(app.config)
    TaskBase = celery.Task

    class ContextTask(TaskBase):
        abstract = True

        def __call__(self, *args, **kwargs):
            with app.app_context():
                return TaskBase.__call__(self, *args, **kwargs)

    celery.Task = ContextTask
    return celery


def create_app(settings_override=None):
    app = Flask(__name__, instance_relative_config=True)

    app.config.from_object('config.settings')
    app.config.from_pyfile('settings.py')

    if settings_override:
        app.config.update(settings_override)

    app.logger.setLevel(app.config['LOG_LEVEL'])

    middleware(app)
    error_templates(app)
    # exception_handler(app)

    @app.context_processor
    def url_processor():
        return {
            'get_static_url': get_static_url,
            'get_url': get_url,
            'get_url_clear': get_url_clear}

    app.register_blueprint(admin)
    app.register_blueprint(user)
    app.register_blueprint(page)
    # app.register_blueprint(search)
    app.register_blueprint(contact)

    app.register_blueprint(api_bp)
    app.register_blueprint(measurement)

    extensions(app)

    authentication(app, User)
    jwt = JWT(app, authenticate, identity)

    return app


def extensions(app):
    """
    Register 0 or more extensions (mutates the app passed in).

    :param app: Flask application instance
    :return: None
    """
    db.init_app(app)
    mail.init_app(app)
    login_manager.init_app(app)
    htmlmin.init_app(app)
    if not app.config['TESTING']:
        sentry = Sentry(dsn=app.config['DSN'])
        sentry.init_app(app)

    return None

# if __name__ == '__main__':
#     from biband.extensions import db
#     db.init_app(app)
#     port = int(os.environ.get('PORT', 5000))
#     app.run(host='0.0.0.0', port=port)


def authentication(app, user_model):
    """
    Initialize the Flask-Login extension (mutates the app passed in).

    :param app: Flask application instance
    :param user_model: Model that contains the authentication information
    :type user_model: SQLAlchemy model
    :return: None
    """
    login_manager.login_view = 'user.login'

    # @login_manager.user_loader
    # def load_user(uid):
    #     return user_model.query.get(uid)

    @login_manager.user_loader
    def load_user(user_token):
        return user_model.query.filter_by(user_token=user_token).first()


def middleware(app):
    """
    Register 0 or more middleware (mutates the app passed in).

    :param app: Flask application instance
    :return: None
    """
    # Swap request.remote_addr with the real IP address even if behind a proxy.
    app.wsgi_app = ProxyFix(app.wsgi_app)

    return None


def error_templates(app):
    """
    Register 0 or more custom error pages (mutates the app passed in).

    :param app: Flask application instance
    :return: None
    """

    def render_status(status):
        """
         Render a custom template for a specific status.
           Source: http://stackoverflow.com/a/30108946

         :param status: Status as a written name
         :type status: str
         :return: None
         """
        # Get the status code from the status, default to a 500 so that we
        # catch all types of errors and treat them as a 500.
        code = getattr(status, 'code', 500)
        return render_template('errors/{0}.html'.format(code)), code

    for error in [404, 500]:
        app.errorhandler(error)(render_status)

    return None


# def exception_handler(app):
#     """
#     Register 0 or more exception handlers (mutates the app passed in).

#     :param app: Flask application instance
#     :return: None
#     """
#     mail_handler = SMTPHandler((app.config.get('MAIL_SERVER'),
#                                 app.config.get('MAIL_PORT')),
#                                app.config.get('MAIL_USERNAME'),
#                                [app.config.get('MAIL_USERNAME')],
#                                '[Exception handler] A 5xx was thrown',
#                                (app.config.get('MAIL_USERNAME'),
#                                 app.config.get('MAIL_PASSWORD')),
#                                secure=())

#     mail_handler.setLevel(logging.ERROR)
#     mail_handler.setFormatter(logging.Formatter("""
#     Time:               %(asctime)s
#     Message type:       %(levelname)s


#     Message:

#     %(message)s
#     """))
#     app.logger.addHandler(mail_handler)
#     print("error happend")

#     return None
